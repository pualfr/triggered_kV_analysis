# -*- coding: utf-8 -*-
"""
Created on Fri May 16 13:51:35 2025

@author: mz-u6265
"""
from pydicom import dcmread #utilisé dans la lecture de fichier DICOM
import os #utilisé pour la gestion de fichier 

# path_pCT="I:/CHR P06 SERVICE RADIOTHERAPIE CURIETHERAPIE MY/RTH/physique/STAGIAIRES/TECHER Quentin/Fichiers DICOM isocal CHR/01pCT"
# path_RTS="I:/CHR P06 SERVICE RADIOTHERAPIE CURIETHERAPIE MY/RTH/physique/STAGIAIRES/TECHER Quentin/Fichiers DICOM isocal CHR/02RTSTRUCT"
# path_RTP="I:/CHR P06 SERVICE RADIOTHERAPIE CURIETHERAPIE MY/RTH/physique/STAGIAIRES/TECHER Quentin/Fichiers DICOM isocal CHR/03RTPLAN"
# path_pkV="I:/CHR P06 SERVICE RADIOTHERAPIE CURIETHERAPIE MY/RTH/physique/STAGIAIRES/TECHER Quentin/Fichiers DICOM isocal CHR/04DRR"
def extract_isoRTP(path):
    """
    Description: prend en entrée les chemins du dossier 
    """
    L=os.listdir(path)
    for i in L:
        ds = dcmread(path +"/"+ i)
        for i in range(0,len(ds.BeamSequence)):
            bs= ds.BeamSequence[i]
            bs=bs.ControlPointSequence[0]
            bs=bs.IsocenterPosition
    return bs

def extract_from_CT(path):
    """
    Description: prend en entrée les chemins du dossier 
    renvoie tout les éléments issue du CT dont le programme a besoin.
    
    Entrée:
    Sortie:
    """
    rc=[]
    L=os.listdir(path)
    CT=[]
    for i in L:
        ds = dcmread(path +"/"+ i)
        di=ds.ImagePositionPatient
        CT.append(di)
        rc.append(ds.Rows)
        rc.append(ds.Columns)
        spacingz=ds.SliceThickness
        spacingxy=ds.PixelSpacing
        
    return CT,rc,spacingxy,spacingz

def isocentre(path_pCT,path_RTP):
    iso_dcm_en_mm=extract_isoRTP(path_RTP)
    
    # INTRODUCTION VOLONTAIARE D'UNE ERREUR
    # --- ERREUR VOLONTAIRE ISO RTPLAN : +1 cm (10 mm) sur X, Y, Z ---
    dx, dy, dz = 0.0, 0.0, 0.0 # en mm
    iso_dcm_en_mm = [
        float(iso_dcm_en_mm[0]) + dx,
        float(iso_dcm_en_mm[1]) + dy,
        float(iso_dcm_en_mm[2]) + dz,
    ]
    
    CT,dim,spacing,spacingz=extract_from_CT(path_pCT)
    L=[]
    for i in CT:
        L.append(i[2])
    CTdz=max(L)
    CTfz=min(L)
    CTd=[]
    CTf=[]
    CTd.append(CT[0][0])
    CTd.append(CT[0][1])
    CTd.append(CTdz)
    CTf.append(CT[0][0])
    CTf.append(CT[0][1])
    CTf.append(CTfz)
    deltax=float(iso_dcm_en_mm[0])-float(CTf[0])
    deltay=float(iso_dcm_en_mm[1])-float(CTf[1])
    rows,columns=dim[0],dim[1]
    decalage_x,decalage_y,decalage_z= float(deltax-(((rows/2)-1)*spacing[0])), float(deltay-(((columns/2)-1)*spacing[1])),float(iso_dcm_en_mm[2]-(((float(CTd[2])+float(CTf[2])-spacingz)/2)))
    # centre de l'image 1.5269999999999868 249.5 -10.0
    # print("position de l'isocentre en pixel avec les dimesions",extract_dimension(path_pCT),"(",deltax,deltay,")",str("slice_n°"),round(deltaz/2),"\n")
    # print("position de l'isocentre en pixel avec les dimesions",[256,256],"(",deltax*256/rows,deltay*256/columns,")",str("slice_n°"),round(deltaz/2),"\n")
    # print("décalage de l'isocentre par rapport au centre en pixel avec les dimesions",[rows,columns],"(",deltax-(rows/2),deltay-(columns/2),")","\n")
    # print("décalage de l'isocentre par rapport au centre en mm est de ","(",(deltax-(rows/2))*spacing[0],(deltay-(columns/2))*spacing[1],")","\n")
    # print("décalage de l'isocentre par rapport en z au centre en mm est de ","(",(deltaz-(len(CT)/2))*spacing[2],")","\n")
    return decalage_x,decalage_y,decalage_z




